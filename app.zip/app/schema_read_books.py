from graphene_sqlalchemy import SQLAlchemyObjectType
from app.read_books_model import ReadBooksModel
import graphene


class ReadBooksAttribute:
    name = graphene.String(description="Name of the book.")
    author = graphene.String(description="Author of the book.")
    date = graphene.Date(description="Date of reading.")


class ReadBooks(SQLAlchemyObjectType, ReadBooksAttribute):
    """Read books node."""

    class Meta:
        model = ReadBooksModel
        interfaces = (graphene.relay.Node,)