from graphene_sqlalchemy import SQLAlchemyConnectionField
import graphene
import app.schema_read_books


class Query(graphene.ObjectType):
    """Query objects for GraphQL API."""

    node = graphene.relay.Node.Field()
    book = graphene.relay.Node.Field(app.schema_read_books.ReadBooks)
    books = SQLAlchemyConnectionField(app.schema_read_books.ReadBooks)


schema = graphene.Schema(query=Query)